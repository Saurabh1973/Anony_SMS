# N-ANOM
<b>N-ANOM<b> is a tool to send sms anonymously

```
  
  $ apt update && apt upgrade 
  
  $ pkg install git -y
  
  $ pkg install python && pkg install python2 -y
  
  $ git clone https://github.com/Nabil-Official/N-ANOM
  
  $ pip3 install requests
  
  $ cd N-ANOM 
  
  $ python3 n-anom.py
  

```

![N-ANOM](https://j.top4top.io/p_1905o7ugw0.png)

